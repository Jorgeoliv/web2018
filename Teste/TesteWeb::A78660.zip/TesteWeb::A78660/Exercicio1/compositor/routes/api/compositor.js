var express = require('express')
var router = express.Router()
var Compositor = require('../../controllers/compositores')

var querystring = require('querystring')

//API para os eventos

router.get('/', (req, res) => {
    if(req.query.periodo && req.query.data){
        Compositor.periodoData(req.query.data, req.query.periodo)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send('Erro na consulta de um compositor: ' + erro))
    }else{
        if(req.query.periodo){
            Compositor.periodo(req.query.periodo)
                .then(dados => res.jsonp(dados))
                .catch(erro => res.status(500).send('Erro na consulta de um compositor: ' + erro))
        }else{
            Compositor.listar()
                .then(dados => res.jsonp(dados))
                .catch(erro => res.status(500).send('Erro na consulta de um compositor: ' + erro))
        }
    }
})

router.get('/:id', (req, res) => {
    Compositor.consultar(req.params.id)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na consulta de um compositor: ' + erro))
})

module.exports = router