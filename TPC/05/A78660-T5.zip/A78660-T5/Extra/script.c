#include <stdio.h>
#include <string.h>

void main(int argc, char **argv){
    //printf(argv[1]);
    for(int i = 1; i<argc; i++){
        printf("Vou analisar o ficheiro %s\n", argv[i]);
        char s[200];
        strcpy(s, "cat ");
        strcat(s, argv[i]);
        strcat(s, " | python -c \"import sys,json;json.loads(sys.stdin.read());print 'OK'\"");
        system(s);
    }

}