var http = require('http')
var fs = require('fs')
var jsonfile = require('jsonfile')
var pug = require('pug')
var formidable = require('formidable')
var express = require('express')
var logger = require('morgan')
var mv = require('mv')

var app = express()
var expRegImage = /image/

//app.use(logger('combined'))

app.get('/', (req, res)=>{
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
    jsonfile.readFile('uploaded/catalogo.json', (erro, resultado) => {
        if(!erro){
            res.end(pug.renderFile('index.pug', {ficheiros: resultado}))
        }else{
            console.log('Erro ao ler o ficheiro: ' + erro)
            res.end(pug.renderFile('erro.pug', {e: 'Servidor temporariamente indisponivel!'}))
        }
    })
})

app.get('/w3.css', (req, res)=>{
    res.writeHead(200, {'Content-Type': 'text/css'})
    fs.readFile('stylesheets/w3.css', (erro,dados) => {
        if(!erro)
            res.write(dados)
        else
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + erro}))
        res.end()    
    })
})

app.get('/index/uploaded/:ficheiro', (req, res) => {
    let file = '/uploaded/' + req.params.ficheiro 
    console.log('O ficheiro que eu quero abrir é ' + file)
    res.sendFile(__dirname + file, erro => {
        if(erro)
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + erro}))
        res.end()
    })
})

app.post('/processaForm', (req,res) => {
    var form = new formidable.IncomingForm()
    form.parse(req, (erro, fields, files) => {
        let result = expRegImage.test(files.ficheiro.type)
        if(!result){
            res.write(pug.renderFile('erro.pug', {e: 'O ficheiro não é do tipo imagem! Tente novamente!'}))
            res.end()
        }
        else{
            var fenviado = files.ficheiro.path
            var fnovo = 'uploaded/' + files.ficheiro.name

            jsonfile.readFile('uploaded/catalogo.json', (erro, resultado) => {
                if(!erro){
                    var obj = {}
                    obj.ficheiro = fnovo
                    obj.descricao = fields.desc
                    obj.nome = files.ficheiro.name
                    let repetido = resultado.some(f => {
                        return f.ficheiro == obj.ficheiro
                    })

                    if(repetido){
                        res.write(pug.renderFile('erro.pug', {e: 'Um ficheiro com o mesmo nome já se encontra no catálogo'}))
                        res.end()
                    }
                    else{
                        mv(fenviado, fnovo, (err) => {
                            if(!err){
                                resultado.push(obj)
                                jsonfile.writeFile('uploaded/catalogo.json', resultado, err => {
                                    if(!err){
                                        console.log('Nao deu erro ao ler o ficheiro')
                                    }else{
                                        res.write(pug.renderFile('erro.pug', {e: 'Deu erro ao guardar o ficheiro no catalogo'}))
                                        console.log('Deu erro ao guardar o ficheiro no catalogo')
                                    }
                                })
                            }else{
                                res.write(pug.renderFile('erro.pug', {e: err}))
                                res.end()
                            }
                        })
                        res.write(pug.renderFile('ficheiro-recebido.pug', {ficheiro: files.ficheiro.name, status: 'Ficheiro Recebido e Guardado com Sucesso'}))
                        res.end()
                    }
                }else{
                    console.log('Deu erro ao ler o ficheiro!')
                    res.end()
                }
            })
        }
    })
})

app.all('*', (req, res) => {
    res.redirect('http://localhost:9999/')
})

http.createServer(app).listen(9999, ()=>{
    console.log("Servidor à escuta na porta 9999 ...")
})