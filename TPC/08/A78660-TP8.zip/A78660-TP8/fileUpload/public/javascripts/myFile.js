$(() => {
    $('#tableFicheiros').load('http://localhost:9999/ficheiro')

    $('#myform').submit(e => {
        e.preventDefault()
        let nomeFicheiro = $('#ficheiro').val().replace(/C:\\fakepath\\/i, '')
        let desc = $('#desc').val()
        ajaxPost(nomeFicheiro, desc)
    })

    function ajaxPost(nomeFicheiro, desc){
        var data = new FormData($('#myform')[0])
        $.ajax({
            type: "POST",
            contentType: false,
            processData: false,
            url: "http://localhost:9999/ficheiro/guardar",
            data: data,
            success: p => {
                alert('Ficheiro guardado com sucesso!')
                $('#tableFicheiros').append('<tr><td><a href=\"upload/' + nomeFicheiro + '\">' + nomeFicheiro + '</a></td> <td>' + desc + '</td> </tr>')
                console.dir(p)
            },
            error: e => {
                alert('Erro no upload: ' + e.responseText)
                console.log('Erro no post: ' + e)
            }
        })
        $('#desc').val('')
        $('#ficheiro').val('')
    }

})