var http = require('http')
var fs = require('fs')
var url = require('url')

http.createServer((req, res) => {
    var myObj = url.parse(req.url, true)
    res.writeHead(200, {'Content-Type': 'text/html'})
    
    var str = myObj.pathname.split("/")
    var inde = str[1]
    var caminho = ""
    if(inde === ("index")){
        caminho = "website/index.html"
    }
    else{
        if(str[2] != null)
            caminho = "website/html/" + str[2] + ".html"
    }

    if(!(caminho === ""))
        fs.readFile(caminho, (erro, dados) => {
            if(!erro)
                res.write(dados)
            else
                res.write('<p><b>ERRO: </b>' + erro + '</p>')
        res.end()
        })
    else{
        res.write('<p><b>ERRO: </b> o URL não cumpre os requisitos!</p>')
        res.end()
    }
}).listen(9999, ()=>{
    console.log('Servidor à escuta na porta 9999 ...')
})