var Compositor = require('../models/compositores')

//Lista de Jogos
module.exports.listar = () => {
    return Compositor
        .find({}, {_id: true, start_date: true, nome: true, dataNasc: true})
        .exec()
}

module.exports.consultar = (oid) => {
    return Compositor
        .findOne({_id: oid})
        .exec()
}

module.exports.periodo = (valor) => {
    return Compositor
        .find({periodo: valor})
        .sort({dataNasc: 1})
        .exec()
}

module.exports.periodoData = (data, periodo) => {
    return Compositor
        .find({periodo: periodo, dataNasc: { $gt: data}})
        .sort({dataNasc: 1})
        .exec()
}