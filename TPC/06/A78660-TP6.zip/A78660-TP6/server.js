var http = require('http')
var url = require('url')
var fs = require('fs')
var pug = require('pug')
var  jsonfile = require('jsonfile')

var {parse} = require('querystring')

var myBD = "tarefas.json"

var myServer = http.createServer((req,res)=>{
    var purl = url.parse(req.url, true)
    var query = purl.query

    console.log('Recebi o pedido: ' + purl.pathname)
    console.log('Com o método: ' + req.method)

    if(req.method == 'GET'){
        if(purl.pathname == '/' || purl.pathname == '/index'){
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            jsonfile.readFile(myBD, (erro, tarefas) =>{
                if(!erro){
                    res.write(pug.renderFile('index.pug', {lista: tarefas}))
                }
                else{
                    res.write(pug.renderFile('erro.pug', {e: "Erro na leitura da BD!"}))
                }
                res.end()
            })
        }
        else if(purl.pathname == '/registo'){
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('form-tarefa.pug'))
            res.end()
        }else if(purl.pathname == '/lista'){
            jsonfile.readFile(myBD, (erro, tarefa) => {
                if(!erro){
                    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                    res.write(pug.renderFile('lista-tarefa.pug', {lista: tarefa}))
                    res.end() 
                }else{
                    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                    res.write(pug.renderFile('erro.pug', {e: "Erro na leitura da BD!"}))
                    res.end()
                }
            })
        }
        else if(purl.pathname == '/processaForm'){
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('tarefa-recebida.pug', {tarefa: query}))
            res.end()
        }else if(purl.pathname == '/w3.css'){
            res.writeHead(200, {'Content-Type': 'text/css'})
            fs.readFile('stylesheets/w3.css', (erro,dados) => {
                if(!erro)
                    res.write(dados)
                else
                    res.write(pug.renderFile('erro.pug', {e: "Erro: " + erro}))
                res.end()    
            })
        }
        else{
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
            res.end()
        }
    }
    else if(req.method == 'POST'){
        console.log("Recebi um metodo post")
        if(purl.pathname == '/processaForm'){
            //processa o body do http que recebe
            recuperaInfo(req, resultado => {
                var today = new Date()
                var dd = today.getDate()
                var mm = today.getMonth()+1
                var yyyy = today.getFullYear()
                today = dd + '/' + mm + '/' + yyyy
                resultado.data = today
                jsonfile.readFile(myBD, (erro, tarefas) =>{
                    if(!erro){
                        var id = tarefas.length
                        resultado.identificador = id
                        tarefas.push(resultado)
                        tarefas.sort((a,b)=>{
                            return a.prazo > b.prazo
                        })
                        console.dir(tarefas)
                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            if(erro)
                                console.log(erro)
                            else
                                console.log('Registo Guardado com Sucesso!')
                        })
                    }
                })
                res.end(pug.renderFile('tarefa-recebida.pug', {tarefa: resultado}))
            })
        } else if(purl.pathname == '/apaga'){
            recuperaInfo(req, resultado =>{
                jsonfile.readFile(myBD, (erro, tarefas) =>{
                    console.dir(tarefas)                    
                    if(!erro){
                        console.log('Vou ver as tarefas')
                        var r = JSON.parse(resultado.objeto)
                        var acao = r.acao
                        var tar = r.ta
                        console.dir(tar)
                        var identifi = tar.identificador
                        for(var i = 0; i<tarefas.length; i++){
                            //console.dir(JSON.parse(resultado.objeto))
                            var obj = JSON.parse(resultado.objeto)
                            
                            //var identifi = obj.identificador
                            //console.dir(tarefas[i])
                           // console.dir(JSON.parse(resultado.objeto))
                            if(tarefas[i].identificador == identifi){
                                console.log("Deu certo!!!")
                                if(acao == 'apaga')
                                    tarefas[i].apagada = 'true'
                                else
                                    tarefas[i].concluida = 'true'    
                            }
                            else
                                console.log("Nao deu!!!")
                        }

                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            if(erro)
                                console.log(erro)
                            else
                             res.end(pug.renderFile('erro.pug', {e: "Erro na escrita da BD!"}))
                        })

                    }else{
                        res.end(pug.renderFile('erro.pug', {e: "Erro: " + erro}))
                    }
                })
                var auxRes = JSON.parse(resultado.objeto)
                res.end(pug.renderFile('tarefa-eliminada.pug', {tarefa: auxRes.ta}))
            })
        }
        else{
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
            res.end()
        }
    }
    else{
        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
        res.write(pug.renderFile('erro.pug', {e: "Método: " + req.method + " não está implementado!"}))
        res.end()
    }
})

myServer.listen(9999, ()=>{
    console.log("Servidor à escuta na porta 9999 ...")
})

function recuperaInfo(request, callback){
    if(request.headers['content-type'] === 'application/x-www-form-urlencoded'){
        let body = ''
        request.on('data', bloco => {
            body += bloco.toString()
        })
        request.on('end', () =>{
            callback(parse(body))
        })
    }
    else callback(null)
}