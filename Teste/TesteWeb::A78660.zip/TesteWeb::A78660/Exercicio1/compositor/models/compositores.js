var mongoose = require('mongoose')

var Schema = mongoose.Schema

var CompositorSchema = new Schema({
    _id: {type: String},
    nome: {type: String},
    bio: {type: String},
    dataNasc: {type: String},
    dataObito: {type: String},
    periodo: {type: String}
})

module.exports = mongoose.model('Compositor', CompositorSchema, 'compositores')