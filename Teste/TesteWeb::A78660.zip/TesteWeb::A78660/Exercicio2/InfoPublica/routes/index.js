var express = require('express');
var router = express.Router();
const axios = require('axios')

/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(dados => res.render('index', {ind: dados.data}))
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
});

router.get('/classe/nivel/1/:codigo', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.codigo)
    .then(dados =>{
      res.render('template', {infoBase: dados.data[0]})
    })
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
});

router.get('/classe/nivel/2/:codigo', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.codigo)
    .then(dados => {
      res.render('template', {infoBase: dados.data[0], ascendente: 1})
    })
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
});

router.get('/classe/nivel/3/:codigo', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.codigo)
    .then(dados => res.render('template', {infoBase: dados.data[0], ascendente: 2}))
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
});

router.get('/classe/nivel/4/:codigo', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.codigo)
    .then(dados => res.render('template', {infoBase: dados.data[0], ascendente: 3}))
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
});

router.get('/descendencia/:codigo', function(req, res){
  let tam = req.params.codigo.split(".").length + 1
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.codigo + '/descendencia')
    .then(dados => {
      res.render('descendentes', {ind: dados.data, descendente: tam})
    })
    .catch(erro => res.render('error', {message: "Ocooreu um erro ao listar as classes nivel 1!", error: erro}))
})

module.exports = router;
