var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var bodyParser = require('body-parser')
var formidable = require('formidable')
var mv = require('mv')

var expRegImage = /image/
var myDB = __dirname + '/ficheiros.json'

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index')
})

router.get('/ficheiro', (req, res) => {
  jsonfile.readFile(myDB, (erro, paras) => {
    if(!erro){
      res.render('listaFicheiro', {ficheiros: paras})
    }else{
      res.render('error', {e: erro})
    }
  })
})

router.post('/ficheiro/guardar', (req, res) => {
  var form = new formidable.IncomingForm()
  form.parse(req, (erro, fields, files) => {
    let result = expRegImage.test(files.ficheiro.type)
    if(!result){
        res.status(500)
        res.write('O ficheiro não é do tipo imagem! Tente novamente!')
        res.end()
    }
    else{
      console.log('Vou começar a ver coisas')
        var fenviado = files.ficheiro.path
        var fnovo = __dirname + '/../public/upload/' + files.ficheiro.name

        jsonfile.readFile(myDB, (erro, resultado) => {
            if(!erro){
                var obj = {}
                obj.ficheiro = 'upload/' + files.ficheiro.name
                obj.descricao = fields.desc
                obj.nome = files.ficheiro.name
                let repetido = resultado.some(f => {
                    return f.ficheiro == obj.ficheiro
                })

                if(repetido){
                    res.status(500)
                    res.write('Um ficheiro com o mesmo nome já se encontra no catálogo')
                    res.end()
                }
                else{
                    mv(fenviado, fnovo, (erroF) => {
                        if(!erroF){
                            resultado.push(obj)
                            jsonfile.writeFile(myDB, resultado, err => {
                                if(!err){
                                    console.log('Nao deu erro ao ler o ficheiro')
                                    res.json({"success" : "Updated Successfully", "status" : 200})
                                }else{
                                    res.status(500)
                                    res.write('Deu erro ao guardar o ficheiro no catalogo' + err)
                                    res.end()
                                }
                            })
                        }else{
                            res.status(500)
                            res.write('Deu erro a mover o ficheiro! ' + erroF)
                            res.end()
                        }
                    })
                }
            }else{
                res.status(500)
                res.write('Deu erro ao ler o ficheiro!')
                res.end()
            }
        })
    }
})

})

router.all('*', (req, res) => {
    res.redirect("http://localhost:9999/")
})

module.exports = router;
