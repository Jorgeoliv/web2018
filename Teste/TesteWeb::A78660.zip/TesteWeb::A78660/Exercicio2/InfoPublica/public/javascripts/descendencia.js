$(() => {

    let numero = 1
    let codigo = '';
    $('#mytable tr td').each(function(){
        var texto = $(this).text();
        if(numero == 1)
            codigo = texto
        numero++;
    });
    $('#tabelaDados').load('http://localhost:3000/descendencia/' + codigo)
    //# é para um id
    //tenho sempre de por o $ para as funções ...

})